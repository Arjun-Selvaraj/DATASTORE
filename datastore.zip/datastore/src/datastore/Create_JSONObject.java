package datastore;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author ARJUN
 */
class Create_JSONObject { 
   public static void DataInsertion(File temporaryFile, String key,String filepath) throws FileNotFoundException, IOException, ParseException {
        Scanner scan =new Scanner(System.in);
        JSONObject jsonObj1=new JSONObject();
        Object obj = new JSONParser().parse(new FileReader(filepath));
        //filepath holds the value json file which will be assigned key by the user.
        JSONObject jsonObj = (JSONObject) obj; 
        JSONArray jsonArr1 = new JSONArray();
        jsonArr1.add(jsonObj);
        jsonObj1.put(key,jsonArr1);
        FileReader fr=new FileReader(temporaryFile);
        JSONArray jsonArr2=null;
        if(fr.read()==-1){
            //fr(FileReader object) returns one whne the file is empty.
            jsonArr2 = new JSONArray();
            //only the file is empty we create JSON ARRAy to store the values with keys.
            jsonArr2.add(jsonObj1);    
            FileWriter file1 = new FileWriter(temporaryFile);
            //write the file in the same input location
            file1.write(jsonArr2.toJSONString());
            file1.close();
        }
        else{
            //comes directly when the file is not empty
            Object obj1 = new JSONParser().parse(new FileReader(temporaryFile));
            jsonArr2= (JSONArray) obj1;
            Read_Data obj2=new Read_Data();
            int ans=obj2.DataSelectionForDeletion(temporaryFile,key);//function call
            if(ans==0){
            //if key is not present ans is equal to 0.
            //if key is already present ans is equal to 1.
            //duplication of keys is prevented.
            jsonArr2.add(jsonObj1);
            FileWriter file1 = new FileWriter(temporaryFile);
            file1.write(jsonArr2.toJSONString());
            file1.close();
            }
            else{
                System.out.println("Key already present");
            }
        }
        
       
    }
    
}
