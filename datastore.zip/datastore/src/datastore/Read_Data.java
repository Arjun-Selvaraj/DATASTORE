package datastore;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Read_Data {
public static void DataSelection(File temporaryFile,String key) throws FileNotFoundException, IOException, ParseException{
        Object obj = new JSONParser().parse(new FileReader(temporaryFile)); 
        JSONArray jsonArray = (JSONArray) obj; 
        Iterator itr2 = jsonArray.iterator(); 
        int flag=0;

        while (itr2.hasNext()){ 
            Iterator<Map.Entry> itr1 = ((Map) itr2.next()).entrySet().iterator();   
            while (itr1.hasNext()) { 
                Map.Entry pair = itr1.next();
                if(pair.getKey().equals(key)){
                    System.out.println(pair.getKey() + " : " + pair.getValue());
                    flag=1;
                    break;
                }
            }
            if(flag==1){
                break;
            }
        }
        if(flag==0){
            System.out.println("ELEMENT NOT FOUND");
        }
       }       

    //DataSelectionForDeletion and DataSelection both have same functionalities but different return type.
    //DataSelectionForDeletion is used for checking while deletion.
    public int DataSelectionForDeletion(File temporaryFile, String key) throws FileNotFoundException, IOException, ParseException {
        int ans=0;
        Object obj = new JSONParser().parse(new FileReader(temporaryFile)); 
        JSONArray jsonArray = (JSONArray) obj; 
        Iterator itr = jsonArray.iterator(); 
        while (itr.hasNext())  
        { 
            Iterator<Map.Entry> itr1 = ((Map) itr.next()).entrySet().iterator();   
            while (itr1.hasNext()) { 
                Map.Entry pair = itr1.next();
                if(pair.getKey().equals(key)){
                    ans=1;
                    break;
                }
            }
            if(ans==1){
                break;
            }
        }
        return ans;  
    }
    
    //to display all the key-value pairs in the JSON (data store) file.
  public static void DataSelectAll(File temporaryFile) throws FileNotFoundException, IOException, ParseException{ 
       Object obj = new JSONParser().parse(new FileReader(temporaryFile)); 
        JSONArray jsonArray = (JSONArray) obj;
        int cnt=0;
        //to check whether the JSON array is empty or not
        Iterator itr2 = jsonArray.iterator(); 
         while (itr2.hasNext()){ 
            Iterator<Map.Entry> itr1 = ((Map) itr2.next()).entrySet().iterator();   
            while (itr1.hasNext()){ 
                    cnt+=1;
                    Map.Entry pair = itr1.next();
                    System.out.println(pair.getKey() + " : " + pair.getValue());
            }
        }
         //'cnt' variable is unaltered when data store is empty.
         if(cnt==0){
            System.out.println("NO ELEMENT LEFT TO READ");
         }
  }  
    
    
}


   