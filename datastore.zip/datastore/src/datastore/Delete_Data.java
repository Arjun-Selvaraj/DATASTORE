package datastore;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
public class Delete_Data {
    public static void DataDeletion(File temporaryFile,String key) throws FileNotFoundException, IOException, ParseException{
        Object obj1 = new JSONParser().parse(new FileReader(temporaryFile)); 
        JSONArray jsonArrayObject = (JSONArray) obj1; 
        Iterator itr2 = jsonArrayObject.iterator(); 
        //to iterate every elemnt in the array.
        int count=0;
        int flag=0;
        while (itr2.hasNext())  { 
            Iterator<Map.Entry> itr1 = ((Map) itr2.next()).entrySet().iterator(); 
            while (itr1.hasNext()) { 
                Map.Entry pair = itr1.next();
                //checks whether the key matches
                if(pair.getKey().equals(key)){
                    Object remove2=jsonArrayObject.remove(count);
                    flag=1;
                    break;
                }
            }
            if(flag==1){
                break;
            }
            count++;
        }
        if(flag==0){//flag remains zero only when the user key is unfound in the json file
            System.out.println("Element not present");
        }
        else{
            FileWriter temp_file = new FileWriter(temporaryFile);
            temp_file.write(jsonArrayObject.toJSONString());
            temp_file.close();
        }
        }
}