package datastore;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import org.json.simple.parser.ParseException;
public class Datastore {
    public static void main(String[] args) throws IOException, FileNotFoundException, ParseException {
       Scanner sc=new Scanner(System.in);
       System.out.println("Select File store locaion \n1.Default 2.New:\n");
       String  Fullpath="File.json";
       int ch=sc.nextInt(); 
       File dataFile = null;
         if(ch==1){
           dataFile =new File("File1.json");
           //stores in the project folder.
         }
         else if(ch==2){
          System.out.println("Enter file path:");
          sc.nextLine();
          String path=sc.nextLine();
          path+="//File2.json";
          dataFile =new File(path);
         }
         String key;
         boolean flag = dataFile.createNewFile();
         flag=true;
         while(flag){//runs unit exit is called.
            System.out.println("1.Create 2.Read 3.Delete 4.Exit");
            ch=sc.nextInt();
            switch(ch){
                case 1:
                    System.out.println("Key:");
                    key = sc.next();
                    Create_JSONObject obj1 =new Create_JSONObject();
                    obj1.DataInsertion(dataFile,key,Fullpath);
                    break;
                case 2:
                    System.out.println("\n Enter \n1.For displaying all data\n2.For selection based on key\n");
                    int ch1=sc.nextInt();
                    Read_Data obj2=new Read_Data();
                    if(ch1==2){
                    System.out.println("Key:");
                    key = sc.next();
                    obj2.DataSelection(dataFile,key);
                    }
                    else{
                     obj2.DataSelectAll(dataFile);
                    }
                    break;
                case 3:
                    Delete_Data obj3=new Delete_Data();
                    System.out.println("Key:");
                    key = sc.next();
                    Delete_Data.DataDeletion(dataFile,key);
                    break;
                case 4:
                    flag=false;
                    break;
                default:
                    System.out.println("INVALID SELECTION \n ENTER values specified below\n");
            }
        }
         
    }
}
